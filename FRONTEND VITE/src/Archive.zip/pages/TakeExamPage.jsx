import { useEffect, useState, useRef, useCallback } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useForm, Controller } from 'react-hook-form';
import { fetchExamDetails, submitExamAnswers } from '../lib/api.js';
import { toast } from 'sonner';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '../components/ui/Card.jsx';
import Label from '../components/ui/Label.jsx';
import { RadioGroup, RadioGroupItem } from '../components/ui/RadioGroup.jsx';
import Button from '../components/ui/Button.jsx';
import { Alert, AlertDescription, AlertTitle } from '../components/ui/Alert.jsx';

// Função para obter cookie
const getCookie = (name) => {
  const nameEQ = name + '=';
  const ca = document.cookie.split(';');
  for (let i = 0; i < ca.length; i++) {
    let c = ca[i];
    while (c.charAt(0) === ' ') c = c.substring(1, c.length);
    if (c.indexOf(nameEQ) === 0) {
      return decodeURIComponent(c.substring(nameEQ.length, c.length));
    }
  }
  return null;
};

const TakeExamPage = () => {
  const { examId } = useParams();
  const navigate = useNavigate();
  const [exam, setExam] = useState(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [timeLeft, setTimeLeft] = useState(null);
  const [cameraPermission, setCameraPermission] = useState('pending'); // 'pending', 'granted', 'denied'
  const videoRef = useRef(null);

  // Obter dados de autenticação dos cookies
  let userData = null;
  let enrollmentData = null;
  try {
    const userDataString = getCookie('userData');
    if (userDataString) userData = JSON.parse(userDataString);
    const enrollmentDataString = getCookie('enrollmentData');
    if (enrollmentDataString) enrollmentData = JSON.parse(enrollmentDataString);
  } catch (err) {
    console.error('Erro ao analisar cookies:', err);
    toast.error('Falha ao carregar dados do utilizador. Por favor, inicie sessão novamente.');
    navigate('/login');
  }

  const enrollmentId = enrollmentData?.id || userData?.enrollment_id;
  const accessToken = getCookie('access_token');

  // Verificar autenticação
  useEffect(() => {
    if (!accessToken || !enrollmentId) {
      toast.error('Autenticação necessária. Por favor, inicie sessão.');
      navigate('/login');
    }
  }, [accessToken, enrollmentId, navigate]);

  const { control, handleSubmit, trigger } = useForm({
    defaultValues: { answers: {} },
  });

  // Função para submeter a prova
const handleExamSubmit = useCallback(
  async (data) => {
    if (isSubmitting) return;

    setIsSubmitting(true);
    toast.message('A submeter as suas respostas...');

    // Ensure all answers are in array format and properly stringified
    const payload = {
      enrollment_id: Number(enrollmentId),
      exam_id: Number(examId),
      answers: Object.entries(data.answers).map(([question_id, answer]) => {
        let formattedAnswer;
        // Handle different answer types
        if (Array.isArray(answer)) {
          formattedAnswer = answer.length > 0 ? answer.map(String) : ['Não respondida'];
        } else if (typeof answer === 'string' && answer) {
          formattedAnswer = [answer];
        } else if (typeof answer === 'object' && answer !== null) {
          // Handle cases where answer is an object (e.g., from react-hook-form)
          formattedAnswer = [JSON.stringify(answer)];
        } else {
          formattedAnswer = ['Não respondida'];
        }

        return {
          question_id: Number(question_id),
          answer: formattedAnswer,
        };
      }),
    };

    console.log('Submitting payload:', JSON.stringify(payload, null, 2));

    try {
      await submitExamAnswers(payload);
      toast.success('Prova submetida com sucesso!');
      navigate('/student/dashboard');
    } catch (error) {
      console.error('Erro ao submeter a prova:', error);
      toast.error(error.response?.data?.message || 'Falha ao submeter as respostas.');
      setIsSubmitting(false);
    }
  },
  [examId, enrollmentId, navigate, isSubmitting]
);
  // Efeito para acesso à câmera
  useEffect(() => {
    const requestCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({ video: true });
        setCameraPermission('granted');
        if (videoRef.current) {
          videoRef.current.srcObject = stream;
        }
      } catch (err) {
        console.error('Erro ao aceder à câmera:', err);
        setCameraPermission('denied');
        toast.error('Acesso à câmera negado. É necessário para continuar.');
      }
    };

    requestCamera();

    return () => {
      if (videoRef.current && videoRef.current.srcObject) {
        const tracks = videoRef.current.srcObject.getTracks();
        tracks.forEach((track) => track.stop());
      }
    };
  }, []);
const parseJSONSafely = (jsonString, fallback = []) => {
  try {
    return jsonString ? JSON.parse(jsonString) : fallback;
  } catch (error) {
    console.warn('JSON parsing failed:', error);
    return fallback;
  }
};

  // Efeito para carregar detalhes da prova
useEffect(() => {
  if (!examId || !accessToken) return;

  const getExam = async () => {
    setIsLoading(true);
    try {
      const examData = await fetchExamDetails(Number(examId), accessToken);
      // Safer JSON parsing with fallbacks
      const parsedQuestions = examData.questions.map((q) => ({
        ...q,
        options: parseJSONSafely(q.options, []),
        correct_answer: parseJSONSafely(q.correct_answer, []),
      }));
      setExam({ ...examData, questions: parsedQuestions });
      setTimeLeft(examData.duration_minutes * 60);
    } catch (error) {
      console.error('Erro ao carregar a prova:', error);
      toast.error(error.message || 'Falha ao carregar a prova.');
      if (error.response?.status === 401) {
        navigate('/login');
      }
    } finally {
      setIsLoading(false);
    }
  };

  getExam();
}, [examId, accessToken, navigate]);

  // Efeito para o cronômetro
  useEffect(() => {
    if (timeLeft === null || timeLeft <= 0 || cameraPermission !== 'granted') return;

    const timerId = setInterval(() => {
      setTimeLeft((prevTime) => prevTime - 1);
    }, 1000);

    if (timeLeft <= 1) {
      clearInterval(timerId);
      toast.warning('O tempo acabou! A sua prova será submetida automaticamente.');
      trigger().then(() => {
        handleSubmit(handleExamSubmit)();
      });
    }

    return () => clearInterval(timerId);
  }, [timeLeft, cameraPermission, handleSubmit, handleExamSubmit, trigger]);

  // Renderizar estado de carregamento
  if (isLoading) {
    return <div className="flex justify-center items-center h-screen">A carregar a prova...</div>;
  }

  // Renderizar negação de permissão da câmera
  if (cameraPermission !== 'granted') {
    return (
      <div className="flex justify-center items-center h-screen bg-gray-50 p-4">
        <Card className="max-w-md text-center shadow-lg">
          <CardHeader>
            <CardTitle className="text-xl text-red-600">Acesso à Câmera Necessário</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="mb-4">
              O acesso à câmera é obrigatório para garantir a integridade da prova. Por favor, autorize o acesso.
            </p>
            {cameraPermission === 'denied' && (
              <Alert variant="destructive">
                <AlertTitle>Acesso Negado!</AlertTitle>
                <AlertDescription>
                  Por favor, ative o acesso à câmera nas configurações do seu navegador e recarregue a página.
                </AlertDescription>
              </Alert>
            )}
            <Button onClick={() => window.location.reload()} className="mt-4">
              Tentar Novamente
            </Button>
          </CardContent>
        </Card>
      </div>
    );
  }

  // Formatar tempo para exibição
  const formatTime = (seconds) => {
    const minutes = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${String(minutes).padStart(2, '0')}:${String(secs).padStart(2, '0')}`;
  };

  // Renderização principal da prova
  return (
    <div className="p-4 sm:p-6 lg:p-8 bg-gray-50 min-h-screen">
      <div className="fixed top-4 right-4 z-10 border-4 border-white rounded-lg shadow-lg overflow-hidden">
        <video
          ref={videoRef}
          autoPlay
          playsInline
          muted
          className="w-48 h-36 object-cover transform -scale-x-100"
        />
      </div>
      <Card className="max-w-3xl mx-auto border-0 shadow-lg">
        <CardHeader>
          <div className="flex justify-between items-start">
            <div>
              <CardTitle className="text-2xl font-bold text-gray-800">{exam?.exam_name}</CardTitle>
              <CardDescription>Disciplina: {exam?.discipline_name}</CardDescription>
            </div>
            <div className="text-right">
              <span className="text-lg font-bold text-red-500 bg-red-100 px-3 py-1 rounded">
                {timeLeft !== null ? formatTime(timeLeft) : '...'}
              </span>
              <p className="text-sm text-gray-500">Tempo Restante</p>
            </div>
          </div>
        </CardHeader>
        <form onSubmit={handleSubmit(handleExamSubmit)}>
          <CardContent className="space-y-6">
{exam?.questions.map((q, index) => (
  <Card key={q.id} className="p-4 bg-white">
    <Label className="font-semibold text-md mb-3 block">
      Questão {index + 1}: {q.text} ({q.score} pontos)
    </Label>
    <Controller
      name={`answers.${q.id}`}
      control={control}
      rules={{ required: 'Esta questão é obrigatória.' }}
      render={({ field, fieldState }) => (
        <>
          {q.type === 'true_false' && (
            <RadioGroup
              onValueChange={(value) => field.onChange([value])}
              value={field.value?.[0] || ''}
              className="space-y-1"
            >
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="true" id={`q${q.id}-true`} />
                <Label htmlFor={`q${q.id}-true`}>Verdadeiro</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="false" id={`q${q.id}-false`} />
                <Label htmlFor={`q${q.id}-false`}>Falso</Label>
              </div>
            </RadioGroup>
          )}
          {q.type === 'multiple_choice' && (
            <RadioGroup
              onValueChange={(value) => field.onChange([value])}
              value={field.value?.[0] || ''}
              className="space-y-1"
            >
              {/* Safer options handling */}
              {Array.isArray(q.options) && q.options.length > 0 ? (
                q.options.map((option, optIndex) => (
                  <div key={optIndex} className="flex items-center space-x-2">
                    <RadioGroupItem
                      value={String(option)}
                      id={`q${q.id}-opt${optIndex}`}
                    />
                    <Label htmlFor={`q${q.id}-opt${optIndex}`} className="cursor-pointer">
                      {String(option)}
                    </Label>
                  </div>
                ))
              ) : (
                <div className="text-red-500 text-sm">
                  Erro: Opções não disponíveis para esta questão
                </div>
              )}
            </RadioGroup>
          )}
          {q.type === 'essay' && (
            <textarea
              onChange={(e) => field.onChange([e.target.value])}
              value={field.value?.[0] || ''}
              placeholder="A sua resposta..."
              className="w-full p-2 border rounded-md"
              rows="4"
            />
          )}
          {fieldState.error && (
            <p className="text-sm text-red-500 mt-1">{fieldState.error.message}</p>
          )}
        </>
      )}
    />
  </Card>
))}
          </CardContent>
          <div className="p-6">
            <Button type="submit" className="w-full text-lg" disabled={isSubmitting}>
              {isSubmitting ? 'A submeter...' : 'Finalizar e Entregar Prova'}
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
};

export default TakeExamPage;