import React, { useState, useEffect } from 'react';
import StudentLayout from '../components/StudentLayout';
import { api } from '../lib/api';
import { Network, BookOpen, Brain, Target, Loader2, AlertTriangle } from 'lucide-react';

const ContentMatrixPage = () => {
  const [enrollmentId, setEnrollmentId] = useState(null);
  const [matrices, setMatrices] = useState([]);
  const [loading, setLoading] = useState(true);
  const [studentCourseId, setStudentCourseId] = useState(null);
  const [allDisciplines, setAllDisciplines] = useState(new Map());

  useEffect(() => {
    const storedEnrollmentId = localStorage.getItem('enrollmentId');
    if (storedEnrollmentId) {
      setEnrollmentId(parseInt(storedEnrollmentId, 10));
    } else {
      setLoading(false);
      console.warn('No enrollmentId found in localStorage');
    }
  }, []);

  useEffect(() => {
    const fetchInitialData = async () => {
      if (!enrollmentId) return;
      setLoading(true);
      try {
        const [enrollmentRes, disciplinesRes] = await Promise.all([
          api.get(`/enrollments/${enrollmentId}/details`),
          api.get('/disciplines'),
        ]);

        setStudentCourseId(enrollmentRes.data.course_id);

        const disciplinesForCourse = disciplinesRes.data.filter(
          (d) => d.course_id === enrollmentRes.data.course_id || !d.course_id
        );
        const dMap = new Map(disciplinesForCourse.map((d) => [d.id, d]));
        setAllDisciplines(dMap);
      } catch (error) {
        console.error('Error fetching initial data for matrices:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchInitialData();
  }, [enrollmentId]);

  useEffect(() => {
    if (!studentCourseId || allDisciplines.size === 0 || !enrollmentId) {
      setLoading(false);
      return;
    }

    const fetchMatrices = async () => {
      setLoading(true);
      try {
        const studentDisciplineIds = Array.from(allDisciplines.keys());
        const matrixPromises = studentDisciplineIds.map((disciplineId) =>
          api.get(`/content-matrices/by-discipline/${disciplineId}`)
        );
        const matrixResponses = await Promise.all(matrixPromises);

        const allMatrices = matrixResponses
          .flatMap((response) => response.data)
          .map((m) => ({
            ...m,
            competencies: Array.isArray(m.competencies) ? m.competencies : JSON.parse(m.competencies || '[]'),
            skills: Array.isArray(m.skills) ? m.skills : JSON.parse(m.skills || '[]'),
          }));

        setMatrices(allMatrices);
      } catch (error) {
        console.error('Error loading content matrices:', error);
      } finally {
        setLoading(false);
      }
    };
    fetchMatrices();
  }, [studentCourseId, allDisciplines, enrollmentId]);

  if (loading) {
    return (
      <StudentLayout enrollmentId={enrollmentId}>
        <div className="flex justify-center items-center h-64">
          <Loader2 className="h-12 w-12 animate-spin text-sky-500" />
        </div>
      </StudentLayout>
    );
  }

  return (
    <StudentLayout enrollmentId={enrollmentId}>
      <div>
        <h1 className="text-3xl font-bold text-slate-800 max-[1px]:text-slate-100 mb-2">Matrizes Curriculares</h1>
        <p className="text-slate-600 max-[1px]:text-slate-400 mb-8">Consulte os temas, competências e habilidades das disciplinas do seu curso.</p>

        {matrices.length > 0 ? (
          <div className="space-y-6">
            {matrices.map((matrix) => (
              <div key={matrix.id} className="bg-white max-[1px]:bg-slate-800 p-6 rounded-xl shadow-lg">
                <div className="mb-4">
                  <h2 className="text-xl font-semibold text-sky-600 max-[1px]:text-sky-400 flex items-center">
                    <BookOpen className="mr-3 h-6 w-6" /> {matrix.discipline_name}
                  </h2>
                  <p className="text-md font-medium text-slate-700 max-[1px]:text-slate-200 mt-1">Tema: {matrix.theme}</p>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <h4 className="font-semibold text-slate-600 max-[1px]:text-slate-300 mb-2 flex items-center">
                      <Brain className="mr-2 h-5 w-5 text-purple-500" />Competências:
                    </h4>
                    {matrix.competencies && matrix.competencies.length > 0 ? (
                      <ul className="list-disc list-inside pl-2 space-y-1 text-sm text-slate-600 max-[1px]:text-slate-400">
                        {matrix.competencies.map((comp, i) => (
                          <li key={i}>{comp}</li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-sm text-slate-500 max-[1px]:text-slate-400 italic">Nenhuma competência listada.</p>
                    )}
                  </div>
                  <div>
                    <h4 className="font-semibold text-slate-600 max-[1px]:text-slate-300 mb-2 flex items-center">
                      <Target className="mr-2 h-5 w-5 text-green-500" />Habilidades:
                    </h4>
                    {matrix.skills && matrix.skills.length > 0 ? (
                      <ul className="list-disc list-inside pl-2 space-y-1 text-sm text-slate-600 max-[1px]:text-slate-400">
                        {matrix.skills.map((skill, i) => (
                          <li key={i}>{skill}</li>
                        ))}
                      </ul>
                    ) : (
                      <p className="text-sm text-slate-500 max-[1px]:text-slate-400 italic">Nenhuma habilidade listada.</p>
                    )}
                  </div>
                </div>

                {matrix.syllabus && (
                  <div className="mt-6">
                    <h4 className="font-semibold text-slate-600 max-[1px]:text-slate-300 mb-2">Ementa / Conteúdo Programático:</h4>
                    <div className="prose prose-sm max-[1px]:prose-invert max-w-none text-slate-600 max-[1px]:text-slate-400 p-3 bg-slate-50 max-[1px]:bg-slate-700/30 rounded-md whitespace-pre-wrap">
                      {matrix.syllabus}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        ) : (
          <div className="text-center bg-white max-[1px]:bg-slate-800 p-10 rounded-lg shadow">
            <AlertTriangle className="mx-auto h-12 w-12 text-yellow-400" />
            <h3 className="mt-2 text-lg font-medium text-slate-900 max-[1px]:text-slate-100">Nenhuma Matriz Encontrada</h3>
            <p className="mt-1 text-sm text-slate-500 max-[1px]:text-slate-400">
              Não há matrizes curriculares disponíveis para as disciplinas do seu curso no momento.
            </p>
          </div>
        )}
      </div>
    </StudentLayout>
  );
};

export default ContentMatrixPage;